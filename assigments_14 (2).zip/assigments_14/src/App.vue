<template>
  <div id="app">
    <game-board></game-board>
  </div>
</template>

<script>
import GameBoard from './components/GameBoard.vue';

export default {
  components: {
    GameBoard
  }
};
</script>
