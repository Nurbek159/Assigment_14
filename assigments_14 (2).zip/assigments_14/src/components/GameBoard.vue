<template>
    <div class="game-board">
      <div v-for="(row, rowIndex) in board" :key="rowIndex" class="row">
        <div v-for="(cell, colIndex) in row" :key="colIndex" class="cell" @click="makeMove(rowIndex, colIndex)">
          {{ cell }}
        </div>
      </div>
      <button v-if="gameOver" @click="restartGame">Restart</button>
      <div class="status">
        <p>Current Player: {{ currentPlayer }}</p>
        <p>Wins: {{ scores.X }}</p>
        <p>Losses: {{ scores.O }}</p>
        <p>Draws: {{ scores.draw }}</p>
      </div>
    </div>
  </template>
  
  <script>
  export default {
    data() {
      return {
        board: [
          ['', '', ''],
          ['', '', ''],
          ['', '', '']
        ],
        currentPlayer: 'X',
        gameOver: false,
        scores: {
          X: 0,
          O: 0,
          draw: 0
        }
      };
    },
    methods: {
      makeMove(row, col) {
        if (!this.gameOver && this.board[row][col] === '') {
          this.board[row][col] = this.currentPlayer;
          if (this.checkWin(this.currentPlayer)) {
            alert(this.currentPlayer + ' wins!');
            this.scores[this.currentPlayer]++;
            this.gameOver = true;
          } else if (this.checkDraw()) {
            alert('It\'s a draw!');
            this.scores.draw++;
            this.gameOver = true;
          } else {
            this.currentPlayer = this.currentPlayer === 'X' ? 'O' : 'X';
          }
        }
      },
      checkWin(player) {
        // Check rows
        for (let i = 0; i < 3; i++) {
          if (
            this.board[i][0] === player &&
            this.board[i][1] === player &&
            this.board[i][2] === player
          ) {
            return true;
          }
        }
  
        // Check columns
        for (let i = 0; i < 3; i++) {
          if (
            this.board[0][i] === player &&
            this.board[1][i] === player &&
            this.board[2][i] === player
          ) {
            return true;
          }
        }
  
        // Check diagonals
        if (
          this.board[0][0] === player &&
          this.board[1][1] === player &&
          this.board[2][2] === player
        ) {
          return true;
        }
        if (
          this.board[0][2] === player &&
          this.board[1][1] === player &&
          this.board[2][0] === player
        ) {
          return true;
        }
  
        return false;
      },
      checkDraw() {
        for (let i = 0; i < 3; i++) {
          for (let j = 0; j < 3; j++) {
            if (this.board[i][j] === '') {
              return false;
            }
          }
        }
        return true;
      },
      restartGame() {
        this.board = [
          ['', '', ''],
          ['', '', ''],
          ['', '', '']
        ];
        this.currentPlayer = 'X';
        this.gameOver = false;
      }
    }
  };
  </script>
  
  <style scoped>
  /* Add styling for the game board and cells */
  .game-board {
    display: inline-block;
    border: 1px solid #ccc;
    padding: 10px;
    background-color: #f5f5f5;
  }
  
  .row {
    display: flex;
  }
  
  .cell {
    display: flex;
    justify-content: center;
    align-items: center;
    width: 50px;
    height: 50px;
    border: 1px solid #ccc;
    cursor: pointer;
    font-size: 24px;
  }
  
  button {
    margin-top: 10px;
  }
  
  .status {
    margin-top: 10px;
  }
  </style>